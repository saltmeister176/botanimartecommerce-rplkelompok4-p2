"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { User, Lock } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const router = useRouter();
  const [isRegister, setIsRegister] = useState(false);

  const [formData, setFormData] = useState({
    phone: "",
    password: "",
    name: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isRegister) {
      toast.success("Account created successfully!");

      localStorage.setItem(
        "user",
        JSON.stringify({
          phone: formData.phone,
          name: formData.name,
          role: "customer",
        })
      );

      router.push("/");
    } else {
      if (formData.phone === "admin" && formData.password === "admin") {
        toast.success("Welcome Admin!");

        localStorage.setItem(
          "user",
          JSON.stringify({
            phone: "admin",
            name: "Admin",
            role: "admin",
          })
        );

        router.push("/admin");
      } else if (
        formData.phone === "manager" &&
        formData.password === "manager"
      ) {
        toast.success("Welcome Store Manager!");

        localStorage.setItem(
          "user",
          JSON.stringify({
            phone: "manager",
            name: "Store Manager",
            role: "store_manager",
          })
        );

        router.push("/store-manager");
      } else {
        toast.success("Login successful!");

        localStorage.setItem(
          "user",
          JSON.stringify({
            phone: formData.phone,
            name: "User",
            role: "customer",
          })
        );

        router.push("/");
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="max-w-md w-full">
        {/* HEADER */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 mb-4">
            <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg">
              🌿
            </div>
            <span className="text-2xl text-primary">Botani Mart</span>
          </div>

          <h2 className="text-2xl">
            {isRegister ? "Create Account" : "Welcome Back"}
          </h2>

          <p className="text-muted-foreground">
            {isRegister
              ? "Sign up to start shopping"
              : "Sign in to your account"}
          </p>
        </div>

        {/* FORM */}
        <div className="bg-card border rounded-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label>Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  className="w-full border p-2 rounded"
                  placeholder="Enter your name"
                />
              </div>
            )}

            <div>
              <label>Phone Number</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                className="w-full border p-2 rounded"
                placeholder="08xxx"
              />
            </div>

            <div>
              <label>Password</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) =>
                  setFormData({ ...formData, password: e.target.value })
                }
                className="w-full border p-2 rounded"
                placeholder="password"
              />
            </div>

            <button className="w-full bg-primary text-white py-2 rounded">
              {isRegister ? "Create Account" : "Sign In"}
            </button>
          </form>

          {/* TOGGLE */}
          <div className="text-center mt-4">
            <button
              onClick={() => setIsRegister(!isRegister)}
              className="text-primary"
            >
              {isRegister
                ? "Already have account? Sign in"
                : "Don't have account? Sign up"}
            </button>
          </div>

          {/* DEMO INFO */}
          <div className="mt-4 text-sm text-gray-500 text-center">
            Admin: admin / admin <br />
            Manager: manager / manager
          </div>
        </div>
      </div>
    </div>
  );
}