"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Package,
  Users,
  Activity,
  Image as ImageIcon,
  LogOut,
  Plus,
  Edit,
  Trash2,
  TrendingUp,
  DollarSign,
  ShoppingCart,
  CheckCircle,
  XCircle,
} from "lucide-react";

import {
  products as initialProducts,
  users as initialUsers,
  activityLogs,
  orders,
  formatPrice,
  formatDate,
} from "@/data/mockData";

import { toast } from "sonner";

type Tab = "dashboard" | "products" | "users" | "logs" | "content";

export default function AdminPage() {
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [user, setUser] = useState<any>(null);
  const [products, setProducts] = useState(initialProducts);
  const [users, setUsers] = useState(initialUsers);

  useEffect(() => {
    const userData = localStorage.getItem("user");

    if (!userData) {
      router.push("/login");
      return;
    }

    const parsed = JSON.parse(userData);

    if (parsed.role !== "admin") {
      router.push("/dashboard");
    } else {
      setUser(parsed);
    }
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.push("/");
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(products.filter((p) => p.id !== id));
      toast.success("Product deleted successfully");
    }
  };

  const handleToggleUserStatus = (userId: string) => {
    setUsers(
      users.map((u) =>
        u.id === userId ? { ...u, isActive: !u.isActive } : u
      )
    );
    toast.success("User status updated");
  };

  if (!user) return null;

  const totalProducts = products.length;
  const totalUsers = users.filter((u) => u.role === "customer").length;

  const totalRevenue = orders
    .filter((o) => o.status === "completed")
    .reduce((sum, o) => sum + o.total, 0);

  const pendingOrders = orders.filter(
    (o) => o.status === "pending" || o.status === "payment_verification"
  ).length;

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "products", label: "Products", icon: Package },
    { id: "users", label: "Users", icon: Users },
    { id: "logs", label: "Activity Logs", icon: Activity },
    { id: "content", label: "Content", icon: ImageIcon },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      {/* SIDEBAR */}
      <aside className="w-64 bg-sidebar text-sidebar-foreground border-r flex flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center space-x-2">
            <span className="text-xl">🌿 Admin Panel</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as Tab)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg ${
                  activeTab === item.id
                    ? "bg-primary text-white"
                    : "hover:bg-muted"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t">
          <button
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-muted"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* MAIN */}
      <main className="flex-1 p-8">
        {/* DASHBOARD */}
        {activeTab === "dashboard" && (
          <div className="grid grid-cols-4 gap-6">
            <div className="p-6 bg-card border rounded-lg">
              <Package />
              <p>Total Products</p>
              <h2>{totalProducts}</h2>
            </div>

            <div className="p-6 bg-card border rounded-lg">
              <Users />
              <p>Total Users</p>
              <h2>{totalUsers}</h2>
            </div>

            <div className="p-6 bg-card border rounded-lg">
              <ShoppingCart />
              <p>Pending Orders</p>
              <h2>{pendingOrders}</h2>
            </div>

            <div className="p-6 bg-card border rounded-lg">
              <DollarSign />
              <p>Revenue</p>
              <h2>{formatPrice(totalRevenue)}</h2>
            </div>
          </div>
        )}

        {/* PRODUCTS */}
        {activeTab === "products" && (
          <div>
            <h1 className="text-xl mb-4">Products</h1>

            <table className="w-full border">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td>{p.name}</td>
                    <td>{formatPrice(p.price)}</td>
                    <td>{p.stock}</td>
                    <td>
                      <button onClick={() => handleDeleteProduct(p.id)}>
                        <Trash2 />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* USERS */}
        {activeTab === "users" && (
          <div>
            <h1>User Management</h1>

            {users.map((u) => (
              <div key={u.id} className="flex gap-4 p-2 border-b">
                <span>{u.name}</span>
                <button onClick={() => handleToggleUserStatus(u.id)}>
                  {u.isActive ? "Deactivate" : "Activate"}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* LOGS */}
        {activeTab === "logs" && (
          <div>
            <h1>Logs</h1>
            {activityLogs.map((log) => (
              <div key={log.id}>
                {log.details} - {formatDate(log.timestamp)}
              </div>
            ))}
          </div>
        )}

        {/* CONTENT */}
        {activeTab === "content" && (
          <div>
            <h1>Content Management</h1>
            <p>Upload banner, promo, etc</p>
          </div>
        )}
      </main>
    </div>
  );
}